from setuptools import setup, find_packages

setup(
    name="toolix",
    version="1.0.0",
    description="Outil en ligne de commande pour la manipulation et le traitement de matrices",
    author="Toolix Team",
    packages=find_packages(),
    package_data={
        "toolix": ["help.txt", "data.csv"],
    },
    install_requires=[
        "pandas",
        "numpy",
    ],
    entry_points={
        "console_scripts": [
            "toolix=toolix.main:main",
        ],
    },
    python_requires=">=3.8",
)
