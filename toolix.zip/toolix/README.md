# Toolix

**Outil en ligne de commande pour la manipulation et le traitement de matrices.**

Toolix permet de lire des fichiers CSV, d'appliquer des opérations sur des matrices (lignes, colonnes, calculs, tri, filtres, transposition…) et d'exporter les résultats dans différents formats.

---

## Installation

```bash
pip install .
```

Ou en mode développement (modifiable à chaud) :

```bash
pip install -e .
```

---

## Utilisation

```bash
toolix -i data.csv --remove_row=1
toolix -i data.csv --sort_col=1,asc
toolix -i data.csv --compute_col=sum(1,2) --output=resultat.csv
```

### Principales commandes

| Commande | Description |
|---|---|
| `--remove_row=indice` | Supprimer des lignes |
| `--remove_col=indice` | Supprimer des colonnes |
| `--insert_row=index,valeur` | Insérer une ligne |
| `--insert_col=index,valeur` | Insérer une colonne |
| `--compute_row=fonction(indices)` | Calcul sur lignes (sum, average, min, max, std) |
| `--compute_col=fonction(indices)` | Calcul sur colonnes |
| `--sort_row=indice,asc\|desc` | Trier les colonnes d'une ligne |
| `--sort_col=indice,asc\|desc` | Trier les lignes d'une colonne |
| `--transpose` | Transposer la matrice |
| `--reverse_row` | Inverser l'ordre des lignes |
| `--reverse_col` | Inverser l'ordre des colonnes |
| `--filter_row=row,op,val` | Filtrer une ligne |
| `--filter_col=col,op,val` | Filtrer une colonne |
| `--create=n,m` | Créer une matrice vide n×m |
| `--put_at=i,j,fichier.csv` | Coller une matrice dans une autre |
| `--output=fichier.ext` | Exporter (csv, html, json, latex, cpp) |

Utilisez `toolix --help` pour la liste complète.

---

## Structure du projet

```
toolix_package/
├── toolix/
│   ├── __init__.py
│   ├── main.py        # Point d'entrée principal
│   ├── operation.py   # Opérations sur matrices
│   ├── calculs.py     # Calculs (sum, avg, min, max…)
│   ├── export.py      # Export CSV, HTML, JSON, LaTeX, C++
│   ├── indice.py      # Gestion des indices
│   ├── help.txt       # Aide en ligne
│   └── data.csv       # Fichier de données exemple
├── setup.py
├── pyproject.toml
└── README.md
```

---

## Dépendances

- Python ≥ 3.8
- pandas
- numpy
